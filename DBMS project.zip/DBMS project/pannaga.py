from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from tenants import Tenant
from Payment import payment
from houseform import houses
from type import type
from user import user

import random

from tkinter import messagebox
class pannu:
    def __init__(self,root):
        self.root=root
        self.root.title("LOGIN")
        self.root.geometry("1550x800+0+0")
        #**********************put image on the screen************************#
        self.bg=ImageTk.PhotoImage(file=r"C:\Users\naikr\OneDrive\Desktop\ranjita\1700222.jpg")
        
        lbl_bg=Label(self.root,image=self.bg)
        lbl_bg.place(x=0,y=0,relwidth=1,relheight=1)
#********************************************************************/

        frame=Frame(self.root,bg="Red")
        frame.place(x=610,y=170,width=340,height=450)
        
        
        
        img1=Image.open(r"C:\Users\naikr\OneDrive\Desktop\ranjita\download (1).png")
        img1=img1.resize((100,100),Image.Resampling.LANCZOS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lbling=Label(image=self.photoimage1,bg="Red",borderwidth=0)
        lbling.place(x=730,y=175,width=100,height=100)

        get_str=Label(frame,text="get started",font=("times new roman",20,"bold"),fg="white",bg="purple")
        get_str.place(x=100,y=100)
        username=lbl=Label(frame,text="username",font=("times new roman",18,"bold"),fg="white",bg="black")
        username.place(x=70,y=155)
        self.txtuser=ttk.Entry(frame,font=("times new roman",15,"bold"))
        self.txtuser.place(x=40,y=180,width=270)
        
        password=lbl=Label(frame,text="password",font=("times new roman",18,"bold"),fg="white",bg="black")
        password.place(x=70,y=220)

        self.txtpass=ttk.Entry(frame,font=("times new roman",15,"bold"))
        self.txtpass.place(x=40,y=280,width=270)




if __name__ =="__main__":
    root=Tk()
    obj=pannu(root)
    root.mainloop()
    
